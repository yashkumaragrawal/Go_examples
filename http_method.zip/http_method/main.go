package main

import (
    "github.com/gin-gonic/gin"
    "github.com/yashkumaragrawal/Go_examples/task"
)

func main() {
    router := gin.Default()
    //fmt.Println(lib.Getuser())
    router.POST("/post", task.Post)
    router.GET("/search", task.Search)
    router.PUT("/update", task.Update)
    router.GET("/Cursor", task.Curs)
    router.POST("/address", task.Post_add)
    router.DELETE("/deletewithemail", task.Delete)
    router.GET("/projection", task.Projection)
    router.Run(":8080")

}
