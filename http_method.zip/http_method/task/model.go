package task

import ()

type Person struct {
    Name     string  `form:"name" json:"name" binding:"required"`
    Phone_no string  `validate:"phone" form:"phone" json:"phone" binding:"required,numeric"`
    Email    string  `form:"email" json:"email" binding:"email"`
    Dob      string  `form:"dob" json:"dob" binding:"required"`
    Gender   string  `form:"gender" json:"gender" binding:"required"`
    Add      Address `form:"address" json:"address" binding:"required"`
}

type Address struct {
    Line1   string `form:"line1" json:"line1" binding:"required"`
    Line2   string `form:"line2" json:"line2" binding:"required"`
    City    string `form:"city" json:"city" binding:"required"`
    State   string `form:"state" json:"state" binding:"required"`
    Pincode int    `form:"pincode" json:"pincode" binding:"required"`
}
