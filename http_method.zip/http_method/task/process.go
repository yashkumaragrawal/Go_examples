package task

import (
    "cloud.google.com/go/datastore"
    "context"
    "github.com/gin-gonic/gin"
    "google.golang.org/api/iterator"
    "gopkg.in/go-playground/validator.v10"
    "log"
    "net/http"
    "regexp"
)

var projectID string = "augmented-path-265206"
var cursorStr string = ""

func Post(c *gin.Context) {
    ctx := context.Background()
    client, _ := datastore.NewClient(ctx, projectID)
    kind := "Person"
    name := "sampletask6"
    Key := datastore.NameKey(kind, name, nil)
    var person Person
    if err := c.ShouldBindJSON(&person); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }
    v := validator.New()
    v.RegisterValidation("phone", func(fl validator.FieldLevel) bool {
        str := fl.Field().String()
        re := regexp.MustCompile(`^[0][1-9]\d{9}$|^[1-9]\d{9}$`)
        if re.MatchString(str) == true {
            return true
        }
        return false
    })
    err := v.Struct(person)
    if err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }
    if _, err := client.Put(ctx, Key, &person); err != nil {
        log.Fatalf("Failed to save person: %v", err)
    }
    c.JSON(http.StatusOK, gin.H{
        "status": "peron Created successfully",
        "person": person,
    })
}
func Search(c *gin.Context) {
    ctx := context.Background()
    client, _ := datastore.NewClient(ctx, projectID)
    em := c.PostForm("mail")
    query := datastore.NewQuery("Person").Filter("Email =", em)
    it := client.Run(ctx, query)
    var p int
    for {
        var person Person
        _, err := it.Next(&person)
        if err == iterator.Done {
            if p == 0 {
                c.JSON(http.StatusOK, gin.H{
                    "status": "zero person exist for this email",
                })
            }
            break
        }
        if err != nil {
            log.Fatalf("Error fetching next Person Details: %v", err)
        }
        p = p + 1

        c.JSON(http.StatusOK, gin.H{
            "person": person,
        })
    }
}
func Update(c *gin.Context) {
    ctx := context.Background()
    client, _ := datastore.NewClient(ctx, projectID)
    var person Person
    kind := "Person"
    name := c.PostForm("keyname")
    Key := datastore.NameKey(kind, name, nil)

    tx, _ := client.NewTransaction(ctx)

    if err := tx.Get(Key, &person); err != nil {
        _ = client.Delete(ctx, Key)
        c.JSON(http.StatusOK, gin.H{
            "status": "This keyname is not exist so please enter rigth keyname for updating",
        })
    } else {
        person.Name = "sakshi"
        person.Gender = "female"
        if _, err := tx.Put(Key, &person); err != nil {
            log.Fatalf("tx.Put: %v", err)
        }
        if _, err := tx.Commit(); err != nil {
            log.Fatalf("tx.Commit: %v", err)
        }
        c.JSON(http.StatusOK, gin.H{
            "status": "updated",
            "person": person,
        })
    }
}
func Curs(c *gin.Context) {
    ctx := context.Background()
    client, _ := datastore.NewClient(ctx, projectID)
    const pageSize = 4
    query := datastore.NewQuery("Person").Limit(pageSize)
    if cursorStr != "" {
        cursor, err := datastore.DecodeCursor(cursorStr)
        if err != nil {
            log.Fatalf("Bad cursor %q: %v", cursorStr, err)
        }
        query = query.Start(cursor)
    }
    var persons []Person
    var person Person
    it := client.Run(ctx, query)
    _, err := it.Next(&person)
    for err == nil {
        c.JSON(http.StatusOK, gin.H{
            "person": person,
        })
        persons = append(persons, person)
        _, err = it.Next(&person)
    }
    if err != iterator.Done {
        log.Fatalf("Failed fetching results: %v", err)
    }

    nextCursor, _ := it.Cursor()
    cursorStr = nextCursor.String()
}
func Delete(c *gin.Context) {
    ctx := context.Background()
    client, _ := datastore.NewClient(ctx, projectID)
    email_delete := c.PostForm("email_delete")
    query := datastore.NewQuery("Person").Filter("Email =", email_delete)
    it := client.Run(ctx, query)
    var p int
    for {
        var person Person
        Key, err := it.Next(&person)
        if err == iterator.Done {
            if p == 0 {
                c.String(http.StatusOK, "zero person exist for this email")
            }
            break
        }
        if err != nil {
            log.Fatalf("Error fetching next Person Details: %v", err)
        }
        _ = client.Delete(ctx, Key)
        p = p + 1
        c.JSON(http.StatusOK, gin.H{
            "status": "deleted",
            "person": person,
        })
    }

}
func Post_add(c *gin.Context) {
    ctx := context.Background()
    client, _ := datastore.NewClient(ctx, projectID)
    kind := "Address"
    name := "user1"
    Key := datastore.NameKey(kind, name, nil)
    var address Address
    if err := c.ShouldBindJSON(&address); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }
    if _, err := client.Put(ctx, Key, &address); err != nil {
        log.Fatalf("Failed to save User1: %v", err)
    }
    c.String(http.StatusOK, "Address Created successfully and Address details are : %v", address)

}
func Projection(c *gin.Context) {
    ctx := context.Background()
    client, _ := datastore.NewClient(ctx, projectID)
    query := datastore.NewQuery("Person").Project("Name", "Email")
    it := client.Run(ctx, query)
    for {
        var person Person
        if _, err := it.Next(&person); err == iterator.Done {
            break
        } else if err != nil {
            log.Fatal(err)
        }
        c.JSON(http.StatusOK, gin.H{
            "person_name":   person.Name,
            "person_gender": person.Email,
        })
    }
}
